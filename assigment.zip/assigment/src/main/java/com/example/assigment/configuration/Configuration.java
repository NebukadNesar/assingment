package com.example.assigment.configuration;

import org.springframework.stereotype.Component;

@Component
public class Configuration {

}
